Arriva Bus mobile-app (Android) introduction
.....................
Arriva is a mobile-based application for Arriva bus (a subsidary of ArrivaGroup which runs transportation services in UK and across European countries)
In summary, this application  can be used by passengers to view buses routes, schedule trips and buy bus tickets.

STLC
......................
1) Understanding functional requirement specification (FRS)
2) Test Planning
3) Test scenarious ( what areas are to be tested)
4) Test cases (how to test the areas)
5) Test execution
6) Identify defects and write defect report
7) Test Completion

Test Phases:
Smoke test
FRS

Smoke test
.......................
+ Software build downloadable on Google play store
+ Software build downloadable on Google play store via web browser ( Google chrome, Microsoft Edge, and Mozilla firefox)

Understanding FRS
..................
> Interface navigation and responsive

> Plan a journey
 .Form A-Invisible Trades


> Bus services and schedules
 . 

> Location
 .Review and approve exported,imported goods and related documents

> Register
 . 

> Login
 . 

> Tickets
 . 

> Basket
 .
> Search
 .
Test Execution
....................
Required: Android 7.0 and above
Actual device used: Samsung A71-OS 12-UI 4.1 
